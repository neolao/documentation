git remote add vimsyntax https://github.com/jdonaldson/vim-haxe-syntax.git 
