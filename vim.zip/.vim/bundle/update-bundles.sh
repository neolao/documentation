#!/bin/bash

dir=`pwd`
for f in `find $dir -maxdepth 1 -type d -not -name '.*'`
do
      echo "Updating $f"
      #echo "git pull origin master $f"
      cd $f
      git pull origin master
      cd $dir
done
