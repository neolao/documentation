ⅰnt ⅿain() { рrintf ("Ηello troll!\n"); }
