## forklift

Plugin for ForkLift, an FTP application for OS X.

### Requirements

* [ForkLift](http://forkliftapp.com/forklift/)

### Usage

* If `fl` is called without arguments then the current folder is opened in ForkLift. Is equivalent to `fl .`

* If `fl` is called with a directory as the argument, then that directory is opened in ForkLift